from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import praw


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required setting: {name}")
    return value


def build_reddit_client() -> praw.Reddit:
    """Create a read-only PRAW client. No write methods are used by this app."""
    reddit = praw.Reddit(
        client_id=required_env("REDDIT_CLIENT_ID"),
        client_secret=required_env("REDDIT_CLIENT_SECRET"),
        username=required_env("REDDIT_USERNAME"),
        password=required_env("REDDIT_PASSWORD"),
        user_agent=required_env("REDDIT_USER_AGENT"),
        check_for_async=False,
    )
    reddit.read_only = True
    # Verify the token belongs to the account configured by the user.
    me = reddit.user.me()
    if me is None:
        raise RuntimeError("Reddit did not return an authenticated account.")
    expected = required_env("REDDIT_USERNAME").lower()
    if me.name.lower() != expected:
        raise RuntimeError(
            f"Authenticated as u/{me.name}, but .env specifies u/{expected}. "
            "Stopping to avoid syncing the wrong account."
        )
    return reddit


def item_to_record(item: Any, kind: str) -> dict[str, Any]:
    is_submission = hasattr(item, "title") and hasattr(item, "selftext")
    body = item.selftext if is_submission else getattr(item, "body", "")
    title = item.title if is_submission else ""
    subreddit = getattr(getattr(item, "subreddit", None), "display_name", "")
    author_obj = getattr(item, "author", None)
    author = getattr(author_obj, "name", None) if author_obj else "[deleted]"
    return {
        "fullname": getattr(item, "fullname", ""),
        "kind": kind,
        "created_utc": float(getattr(item, "created_utc", 0.0)),
        "subreddit": subreddit or "",
        "author": author or "[deleted]",
        "title": title or "",
        "body": body or "",
        "permalink": getattr(item, "permalink", "") or "",
        "fetched_utc": datetime.now(timezone.utc).timestamp(),
    }


def fetch_activity(reddit: praw.Reddit, limit: int, include_inbox: bool) -> list[dict[str, Any]]:
    """Fetch only the authenticated user's own history and inbox replies."""
    me = reddit.user.me()
    if me is None:
        raise RuntimeError("Not authenticated.")

    records: list[dict[str, Any]] = []

    for submission in me.submissions.new(limit=limit):
        records.append(item_to_record(submission, "my_post"))

    for comment in me.comments.new(limit=limit):
        records.append(item_to_record(comment, "my_comment"))

    # Replies to this account's comments. These are other users' content,
    # so the app displays them verbatim and applies the same short cache TTL.
    for reply in reddit.inbox.replies(limit=limit):
        records.append(item_to_record(reply, "reply_to_me"))

    # Optional unread inbox activity. Requires Reddit approval and the
    # appropriate OAuth permission; never enabled by default.
    if include_inbox:
        for message in reddit.inbox.unread(limit=limit):
            records.append(item_to_record(message, "inbox_unread"))

    # Deduplicate by Reddit fullname, preserving the newest fetched record.
    deduped: dict[str, dict[str, Any]] = {}
    for record in records:
        key = record["fullname"]
        if key:
            deduped[key] = record
    return list(deduped.values())
