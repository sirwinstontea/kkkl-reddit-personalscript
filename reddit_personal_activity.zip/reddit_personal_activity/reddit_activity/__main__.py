from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime, timezone

from dotenv import load_dotenv

from .store import ActivityStore
from .reddit_client import build_reddit_client, fetch_activity


def env_int(name: str, default: int, minimum: int = 1) -> int:
    raw = os.getenv(name, str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise SystemExit(f"{name} must be an integer.") from exc
    if value < minimum:
        raise SystemExit(f"{name} must be at least {minimum}.")
    return value


def main() -> None:
    load_dotenv()
    parser = argparse.ArgumentParser(
        prog="reddit-activity",
        description="Read-only local viewer for your own Reddit account activity.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("sync", help="Fetch your own activity while online.")
    sub.add_parser("show", help="Display cached activity; works offline.")
    sub.add_parser("stats", help="Show counts only.")
    sub.add_parser("clear", help="Delete the local cache.")
    args = parser.parse_args()

    db_path = os.getenv("DATABASE_PATH", "data/activity.sqlite3")
    ttl_hours = env_int("CACHE_TTL_HOURS", 48)
    store = ActivityStore(db_path)
    store.expire(ttl_hours)

    if args.command == "clear":
        store.clear()
        print("Local cache deleted.")
        return

    if args.command == "sync":
        reddit = build_reddit_client()
        limit = env_int("FETCH_LIMIT", 100)
        include_inbox = os.getenv("INCLUDE_INBOX", "false").lower() == "true"
        items = fetch_activity(reddit, limit=limit, include_inbox=include_inbox)
        store.upsert_many(items)
        store.expire(ttl_hours)
        print(f"Synchronised {len(items)} items at {datetime.now(timezone.utc).isoformat()}.")
        print("Only read operations were performed.")
        return

    items = store.list_items()
    if args.command == "stats":
        counts: dict[str, int] = {}
        for item in items:
            counts[item["kind"]] = counts.get(item["kind"], 0) + 1
        print(f"Cached items: {len(items)}")
        for kind, count in sorted(counts.items()):
            print(f"  {kind}: {count}")
        return

    if not items:
        print("No cached activity. Run 'python -m reddit_activity sync' while online.")
        return

    for item in items:
        when = datetime.fromtimestamp(item["created_utc"], timezone.utc).astimezone()
        print("=" * 78)
        print(f"{item['kind']} | {when:%Y-%m-%d %H:%M %Z} | r/{item['subreddit'] or 'unknown'}")
        if item["author"]:
            print(f"Author: u/{item['author']}")
        if item["title"]:
            print(f"Title: {item['title']}")
        if item["permalink"]:
            print(f"Permalink: https://www.reddit.com{item['permalink']}")
        print("-" * 78)
        # Display original content verbatim; no paraphrasing or transformation.
        print(item["body"] or "(No text body)")
    print("=" * 78)


if __name__ == "__main__":
    main()
