from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any


class ActivityStore:
    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS activity (
                    fullname TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    created_utc REAL NOT NULL,
                    subreddit TEXT,
                    author TEXT,
                    title TEXT,
                    body TEXT,
                    permalink TEXT,
                    fetched_utc REAL NOT NULL
                )
                """
            )

    def _connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        return db

    def upsert_many(self, items: list[dict[str, Any]]) -> None:
        with self._connect() as db:
            db.executemany(
                """
                INSERT INTO activity
                (fullname, kind, created_utc, subreddit, author, title, body, permalink, fetched_utc)
                VALUES
                (:fullname, :kind, :created_utc, :subreddit, :author, :title, :body, :permalink, :fetched_utc)
                ON CONFLICT(fullname) DO UPDATE SET
                    kind=excluded.kind,
                    created_utc=excluded.created_utc,
                    subreddit=excluded.subreddit,
                    author=excluded.author,
                    title=excluded.title,
                    body=excluded.body,
                    permalink=excluded.permalink,
                    fetched_utc=excluded.fetched_utc
                """,
                items,
            )

    def expire(self, ttl_hours: int) -> None:
        import time
        cutoff = time.time() - ttl_hours * 3600
        with self._connect() as db:
            db.execute("DELETE FROM activity WHERE fetched_utc < ?", (cutoff,))

    def list_items(self) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM activity ORDER BY created_utc DESC"
            ).fetchall()
        return [dict(row) for row in rows]

    def clear(self) -> None:
        with self._connect() as db:
            db.execute("DELETE FROM activity")
