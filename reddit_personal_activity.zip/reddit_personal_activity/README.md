# Personal Reddit Activity Reader

A local, read-only Python command-line utility for viewing your own Reddit posts,
comments, comment replies, and (optionally) unread inbox items. It is designed to
synchronise while online and display the cached items later without Wi-Fi.

## Important policy boundary

This project deliberately does **not** generate paraphrased summaries of Reddit
posts or comments. Reddit's current Data API Terms (section 2.4, revised July 20,
2026) say User Content may be copied/displayed for the approved app, but may not
be modified except for formatting. The app therefore provides a chronological
feed and simple counts only; it displays text verbatim.

Offline caching and access to inbox content are still subject to Reddit's approval
and terms. This code is not a guarantee of approval or legal compliance. Request
explicit approval for this exact use case before making API calls. In particular,
ask Reddit to confirm that temporary local caching for offline display is allowed.
The default cache lifetime is 48 hours as a conservative setting, not a statement
that Reddit's terms universally prescribe that exact period.

Official references:
- https://redditinc.com/policies/data-api-terms
- https://support.reddithelp.com/hc/en-us/articles/16160319875092-Responsible-Builder-Policy
- https://developers.reddit.com/docs/guides/faq

## Features

- Reads only the authenticated account's own submissions and comments.
- Reads comment replies to the authenticated account.
- Optionally reads unread inbox items (requires the relevant Reddit OAuth permission).
- Stores fetched items in a local SQLite database for short-term offline viewing.
- Displays content verbatim; no LLM, AI, ML, content rewriting, posting, commenting,
  voting, messaging, following, or other write actions.
- Uses PRAW's `read_only=True` mode and requests no posting/voting features.
- Expires cached records after the configured number of hours.

## 1. Create a Reddit app and get approval

Create a Reddit **script** app only if Reddit approves this personal script use case.
Use the client ID and secret shown for that app. Do not use another account or
misrepresent the app's purpose. Use a descriptive User-Agent that identifies the
app and version.

Request only the access your approved use case needs. This app needs account identity
and read access. Reading inbox messages may require Reddit's `privatemessages` scope;
that scope may grant broader permissions than this program uses. Do not enable inbox
reading unless Reddit approves it and you are comfortable granting that OAuth scope.

## 2. Install

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and fill in the credentials from your approved Reddit app.

```bash
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Never share `.env`, your client secret, password, refresh token, or database.

## 3. Configure

Set:
- `REDDIT_CLIENT_ID`
- `REDDIT_CLIENT_SECRET`
- `REDDIT_USERNAME`
- `REDDIT_PASSWORD`
- `REDDIT_USER_AGENT` (use a truthful descriptive value)
- `INCLUDE_INBOX=false` initially; set to `true` only if inbox access is approved.
- `CACHE_TTL_HOURS=48`

This uses Reddit's OAuth password grant for a script app. If Reddit does not approve
or support this authentication flow for your application, stop and use the OAuth
flow Reddit instructs you to use; do not work around an access restriction.

## 4. Use

Synchronise while online:

```bash
python -m reddit_activity sync
```

Show cached activity (works offline):

```bash
python -m reddit_activity show
```

Show counts only:

```bash
python -m reddit_activity stats
```

Delete the local cache:

```bash
python -m reddit_activity clear
```

The app never sends content to an AI service or any external service other than
Reddit's approved API. It does not automatically reply or take actions on Reddit.

## Data handling

The SQLite database is stored in `data/activity.sqlite3`. Treat it as private data.
The cache expires after `CACHE_TTL_HOURS` from the time each item was fetched.
You can clear it at any time with `python -m reddit_activity clear`.

A periodic cache expiry is not a substitute for implementing any deletion obligations
Reddit imposes. The current implementation cannot guarantee immediate detection of
every item deleted or removed on Reddit. If Reddit requires stricter deletion syncing
or a shorter retention period for your approved use, follow that requirement and
adjust or disable caching accordingly.

## Scope / deliberate omissions

This is a personal account activity reader, not a general subreddit scraper.
It does not search Reddit, list subreddit feeds, fetch arbitrary users' profiles,
or crawl comment trees. It fetches only the authenticated user's own history and
account inbox replies/unread items.

The app does not create natural-language summaries of user content because the
current Data API Terms restrict modification of User Content beyond formatting.
The `stats` command reports counts only.
